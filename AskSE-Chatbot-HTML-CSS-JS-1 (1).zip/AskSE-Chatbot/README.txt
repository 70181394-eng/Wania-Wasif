ASKSE CHATBOT - HTML, CSS AND JAVASCRIPT

FILES
- index.html: chatbot page structure
- style.css: chatbot design
- script.js: FAQ matching and chat behavior

HOW TO OPEN
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.
4. Try questions such as:
   - What is the attendance requirement?
   - What are the library timings?
   - When is the fee due?
   - How do I submit my FYP proposal?

IMPORTANT
This is a beginner frontend prototype. It matches keywords in a local FAQ list.
It is NOT yet connected to a hosted AI model and does not include the secure backend,
Roman Urdu, admin FAQ management, or persistent chat history required for the full competition brief.
Add those features in later steps. Do not present this starter as the finished AI project.
