// AskSE Help Desk - starter FAQ chatbot.
// This version uses JavaScript keyword matching, not a hosted AI model.

const faqs = [
  { id: "FAQ-01", keywords: ["lab", "cs-lab", "food", "drink"],
    answer: "CS-LAB-102A is open from 08:00 AM to 06:00 PM, Monday to Friday. Food and drinks are not allowed inside the lab." },
  { id: "FAQ-02", keywords: ["attendance", "80%", "percentage"],
    answer: "Students need at least 80% attendance in each course. A student below 80% cannot sit the final exam of that course." },
  { id: "FAQ-03", keywords: ["library", "book", "timing"],
    answer: "The library is open from 08:30 AM to 08:00 PM, Monday to Thursday, and from 08:30 AM to 12:30 PM on Friday. It is closed on weekends." },
  { id: "FAQ-04", keywords: ["midterm", "retake", "ill", "sick", "medical"],
    answer: "Apply for a retake to the Course Coordinator within 3 working days of the exam, with a medical certificate." },
  { id: "FAQ-05", keywords: ["fee", "fees", "challan", "payment", "spring 2027"],
    answer: "Download the fee challan from the student portal. The last date to pay without a fine is 15-Jan-2027." },
  { id: "FAQ-06", keywords: ["fyp", "project", "proposal", "slate"],
    answer: "Submit the Final Year Project proposal on SLATE by 30-Nov-2026. Each FYP group has 2 or 3 members." },
  { id: "FAQ-07", keywords: ["bus", "transport", "departure"],
    answer: "University buses leave the campus at 01:30 PM and 04:30 PM, Monday to Friday. Bus cards are issued by the Transport Office in Block A." },
  { id: "FAQ-08", keywords: ["help", "contact", "email", "office"],
    answer: "Email helpdesk@se.example.edu or visit Room 210, 09:00 AM to 04:00 PM, Monday to Friday." }
];

const chatForm = document.getElementById("chatForm");
const userInput = document.getElementById("userInput");
const chatBox = document.getElementById("chatBox");

function addMessage(text, className) {
  const message = document.createElement("div");
  message.className = className;
  message.textContent = text;
  chatBox.appendChild(message);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function findAnswer(question) {
  const normalizedQuestion = question.toLowerCase();
  for (const faq of faqs) {
    const matched = faq.keywords.some(keyword => normalizedQuestion.includes(keyword));
    if (matched) return { answer: faq.answer, faqId: faq.id };
  }
  return {
    answer: "Sorry, I could not find this in the department FAQ. Please email helpdesk@se.example.edu or visit Room 210.",
    faqId: null
  };
}

chatForm.addEventListener("submit", function(event) {
  event.preventDefault();
  const question = userInput.value.trim();
  if (question.length === 0) return;
  if (question.length > 300) {
    alert("Message must be 1 to 300 characters.");
    return;
  }
  addMessage(question, "user-message");
  const result = findAnswer(question);
  const citation = result.faqId ? "\nSource: " + result.faqId : "";
  addMessage(result.answer + citation, "bot-message");
  userInput.value = "";
  userInput.focus();
});
